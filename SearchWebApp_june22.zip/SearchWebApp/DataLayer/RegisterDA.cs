﻿
using SearchWebApp.Models;
using System.Data;
using System.Data.SqlClient;

namespace SearchWebApp.DataLayer
{
    public class RegisterDA
    {
         
        public RegisterMdl registerUser(RegisterMdl objRegisterMdl)
        {
            try
            {
                objRegisterMdl.Id = 0;
                using (SqlConnection con = new SqlConnection(Constants._connectionString))
                {
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("SELECT TOP 1 * FROM Users WHERE Email = '" + objRegisterMdl.Email.Trim() + "'", con);
                        cmd.CommandType = System.Data.CommandType.Text;

                        DataTable objDT = new DataTable();
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(objDT);
                            con.Close();

                        }
                        if (objDT.Rows.Count > 0)
                        {
                            if (objDT.Rows[0]["UserId"] != null)
                            {
                                objRegisterMdl.Id = -99;
                            }
                        }
                        else
                        {
                            cmd = new SqlCommand("INSERT INTO Users([FirstName],[LastName],[Email],[Password],[ZipCode],[DateofBirth],[IsTCAggreed],[CreatedDate],[ModifiedDate]) VALUES( '" + objRegisterMdl.FirstName.Trim()
                                                + "','" + objRegisterMdl.LastName.Trim()
                                                + "','" + objRegisterMdl.Email.Trim()
                                                + "','" + objRegisterMdl.Password.Trim()
                                                + "','" + objRegisterMdl.ZipCode.Trim()
                                                + "','" + objRegisterMdl.DateofBirth.Trim()
                                                + "',1,getdate(),getdate()); SELECT @@IDENTITY AS UserId", con);
                            cmd.CommandType = System.Data.CommandType.Text;

                            objDT = new DataTable();
                            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                            {
                                da.Fill(objDT);
                                con.Close();
                                if (objDT.Rows.Count > 0)
                                {
                                    if (objDT.Rows[0]["UserId"] != null)
                                    { 
                                        objRegisterMdl.Id = int.Parse(objDT.Rows[0]["UserId"].ToString());
                                    }


                                }
                            }
                        }
                    }
                    catch (Exception exc)
                    { 
                    }
                }

            }
            catch (Exception ex)
            {
                 
            }
            return objRegisterMdl;

        }
    }
}
