﻿using SearchWebApp.Models;
using System.Data;
using System.Data.SqlClient;

namespace SearchWebApp.DataLayer
{
    public class LoginDA
    {
         

        public LoginMdl validateLogin(LoginMdl objLogin)
        {
            objLogin.Id = 0;
            using (SqlConnection con = new SqlConnection(Constants._connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 * FROM Users WHERE Email = '" + objLogin.Email + "' AND Password = '" + objLogin.Password + "'", con);
                cmd.CommandType = System.Data.CommandType.Text;

                DataTable objDT = new DataTable();
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(objDT);

                    if (objDT.Rows.Count > 0)
                    {
                        if (objDT.Rows[0]["UserId"] != null)
                        {
                            objLogin.Id = int.Parse(objDT.Rows[0]["UserId"].ToString());
                        }

                    }
                }

            }

            return objLogin;

        }

        
    }
}
