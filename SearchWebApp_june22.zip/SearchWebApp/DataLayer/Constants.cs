﻿namespace SearchWebApp.DataLayer
{
    public static class Constants
    {
        public static string _connectionString = "Data Source=DESKTOP-4SO1IAC\\SQLEXPRESS;Failover Partner=myMirrorServerAddress;Initial Catalog=SearchDB;Integrated Security=True;";
    }
}
