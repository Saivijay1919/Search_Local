﻿using SearchWebApp.Models;
using System.Data;
using System.Data.SqlClient;

namespace SearchWebApp.DataLayer
{
    public class ResturantDataDA
    {
        public List<ResturantData> getResturants(ResturantData objResturantData)
        {
            List<ResturantData> objResturantDataList = new List<ResturantData>();

            using (SqlConnection con = new SqlConnection(Constants._connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT   * FROM [ResturantData] WHERE [Address_1] LIKE '%" + objResturantData.SearchText + "%' OR  [Address_2] LIKE '%" + objResturantData.SearchText + "%' OR  [Hotel_Name] LIKE '%" + objResturantData.SearchText + "%' OR  [Postcode] LIKE '%" + objResturantData.SearchText + "%' OR  [Rating] LIKE '%" + objResturantData.SearchText + "%' OR   [Type_of_Food] LIKE '%" + objResturantData.SearchText + "%'", con);
                cmd.CommandType = System.Data.CommandType.Text;

                DataTable objDT = new DataTable();
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(objDT);

                    if (objDT.Rows.Count > 0)
                    {
                        for (int i = 0; i < objDT.Rows.Count; i++)
                        {
                            ResturantData objResturantDatatemp = new ResturantData();


                            objResturantDatatemp.Id = int.Parse(objDT.Rows[i]["Id"].ToString());
                            objResturantDatatemp.Address_1 = objDT.Rows[i]["Address_1"] ==null?"": objDT.Rows[i]["Address_1"].ToString();
                            objResturantDatatemp.Address_2 = objDT.Rows[i]["Address_2"] == null ? "" : objDT.Rows[i]["Address_2"].ToString();
                            objResturantDatatemp.Hotel_Name = objDT.Rows[i]["Hotel_Name"] == null ? "" : objDT.Rows[i]["Hotel_Name"].ToString();
                            objResturantDatatemp.Postcode = objDT.Rows[i]["Postcode"] == null ? "" : objDT.Rows[i]["Postcode"].ToString();
                            objResturantDatatemp.Rating = objDT.Rows[i]["Rating"] == null ? "" : objDT.Rows[i]["Rating"].ToString();
                            objResturantDatatemp.Type_of_Food = objDT.Rows[i]["Type_of_Food"] == null ? "" : objDT.Rows[i]["Type_of_Food"].ToString();

                            objResturantDataList.Add(objResturantDatatemp);
                        } 
                    }
                }

            }

            return objResturantDataList;

        }
    }
}
