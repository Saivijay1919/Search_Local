﻿
function loadyodelapidata() {
    $('#divDataGot').html("Getting data, please wait.....");

    if ($('#firstNameId').val().trim().length <= 0) {

        alert("Town Name is required.");
        return false;
    }
    townName = $('#firstNameId').val().trim();

    const settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://wyre-data.p.rapidapi.com/restaurants/town/" + townName + "",
        "method": "GET",
        "headers": {
            "X-RapidAPI-Host": "wyre-data.p.rapidapi.com",
            "X-RapidAPI-Key": "15ad3502bamshba2227cf5a8313dp16ecc5jsn2f4ace4b039b"
        }
    };

    $.ajax(settings).done(function (response) {
        console.log(response);
        //divDataGot
        var strDispaly = "";
        for (var i = 0; i < response.length; i++) {

            strDispaly += "						<li>   ";
            strDispaly += "                                <div>   ";
            strDispaly += "                                    <h2>   ";
            strDispaly += "                                        " + response[i].BusinessName + " ";
            strDispaly += "                                    </h2>   ";
            strDispaly += "                                    <span>Rating : <strong>" + response[i].RatingValue + "</strong></span>   ";
            strDispaly += "                                    <div>   ";
            strDispaly += "                                      " + response[i].AddressLine2 + "" + response[i].AddressLine3 + "   ";
            strDispaly += "                                       <p>   ";
            strDispaly += "                                           <strong>   ";
            strDispaly += "                                              " + response[i].PostCode + "  ";
            strDispaly += "                                           </strong>   ";
            strDispaly += "                                       </p>   ";
            strDispaly += "                                    </div>   ";
            strDispaly += "                                </div>   ";
            strDispaly += "                            </li>   ";
        }

        $('#divDataGot').html(strDispaly);
    });

}


function searchResturants() {
    if ($('#rdyodelapi').is(':checked')) {
        loadyodelapidata();
    }
    if ($('#rdlocaldb').is(':checked')) {
        loadlocaldata();
    }
}



function loadlocaldata() {
    $('#divDataGot').html("Getting data, please wait.....");

    if ($('#firstNameId').val().trim().length <= 0) {

        alert("Town Name is required.");
        return false;
    }
    townName = $('#firstNameId').val().trim();
    datatoPost = { "SearchText": townName }
    const settings = {

        "url": "../searchresturants",
        "method": "POST",
        "data": datatoPost,
        "dataType": "json",
        "headers": {

        }
    };

    $.ajax(settings).done(function (response) {
        console.log(response);
        //divDataGot
        var strDispaly = "";
        for (var i = 0; i < response.length; i++) {

            strDispaly += "						<li>   ";
            strDispaly += "                                <div>   ";
            strDispaly += "                                    <h2>   ";
            strDispaly += "                                        " + response[i].hotel_Name + " ";
            strDispaly += "                                    </h2>   ";
            strDispaly += "                                    <span>Rating : <strong>" + response[i].rating + "</strong></span>   ";
            strDispaly += "                                    <div>   ";
            strDispaly += "                                      " + response[i].address_1 + "" + response[i].address_2 + "   ";
            strDispaly += "                                       <p>   ";
            strDispaly += "                                           <strong>   ";
            strDispaly += "                                              " + response[i].postcode + "  ";
            strDispaly += "                                           </strong>   ";
            strDispaly += "                                       </p>   ";
            strDispaly += "                                    </div>   ";
            strDispaly += "                                </div>   ";
            strDispaly += "                            </li>   ";
        }

        $('#divDataGot').html(strDispaly);
    });

}