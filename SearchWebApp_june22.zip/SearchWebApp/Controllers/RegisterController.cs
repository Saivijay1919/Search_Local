﻿using Microsoft.AspNetCore.Mvc;
using SearchWebApp.DataLayer;
using SearchWebApp.Models;

namespace SearchWebApp.Controllers
{
    public class RegisterController : Controller
    {
        [Route("signup")]
        public IActionResult Register()
        {
            RegisterMdl objRegisterMdl = new RegisterMdl();
            objRegisterMdl.Id = 0;
            return View(objRegisterMdl);
        }

        [HttpPost]
        [Route("signup")]
        public IActionResult Register(RegisterMdl objRegisterMdl)
        {
            RegisterDA objRegisterDA = new RegisterDA();
            objRegisterMdl = objRegisterDA.registerUser(objRegisterMdl);

            if (objRegisterMdl.Id < 0)
            {
                objRegisterMdl.Message = "Email already registered, Please try again!";
            }
            else if (objRegisterMdl.Id > 0)
            {
                objRegisterMdl.Message = "Registeration Successful, Please continue to Login!";
            }
            else
            {
                objRegisterMdl.Message = "Email already registered, Please try again!";
            }

            return View(objRegisterMdl);
        }



    }
}
