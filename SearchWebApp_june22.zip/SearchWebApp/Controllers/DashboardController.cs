﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SearchWebApp.DataLayer;
using SearchWebApp.Models;

namespace SearchWebApp.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult MyDashboard()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("/searchresturants")]
        public IActionResult getResturantsList([FromForm] ResturantData objResturantData)
        {
              ResturantDataDA objResturantDataDA = new ResturantDataDA();
            List<ResturantData> objResturantDataList =  objResturantDataDA.getResturants(objResturantData);

            return Json(objResturantDataList);
        }
    }
}


