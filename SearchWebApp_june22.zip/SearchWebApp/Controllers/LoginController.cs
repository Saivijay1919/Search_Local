﻿using Microsoft.AspNetCore.Mvc;
using SearchWebApp.DataLayer;
using SearchWebApp.Models;
namespace SearchWebApp.Controllers
{
    public class LoginController : Controller
    {
        [Route("login")]
        [Route("")]
        public IActionResult Login()
        {
            ViewBag.Error = "";
            return View();
        }

        [HttpPost]
        [Route("login")]
        public IActionResult Login(LoginMdl objLogin)
        {

            LoginDA objLoginDA = new LoginDA();
            objLogin = objLoginDA.validateLogin(objLogin);


            if (objLogin.Id > 0)
            {
                return RedirectToAction("MyDashboard", "Dashboard");
            }
            else {
                ViewBag.Error = "Invalid Credentials, Please try again!";
            }

            return View(objLogin);
        }


    }
}
