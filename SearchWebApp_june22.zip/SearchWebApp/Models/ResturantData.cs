﻿namespace SearchWebApp.Models
{
    public class ResturantData
    {
        public int Id { get; set; }
        public string SearchText { get; set; }
        public string Address_1 { get; set; }
        public string Address_2 { get; set; }
        public string Hotel_Name { get; set; }
        public string Postcode { get; set; }
        public string Rating { get; set; }
        public string Type_of_Food { get; set; }
    }
}
